export { View as Logo } from './view';
