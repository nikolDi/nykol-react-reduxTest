export const GENDER = {
	male: 'male',
	female: 'female',
	indeterminate: 'indeterminate',
};
