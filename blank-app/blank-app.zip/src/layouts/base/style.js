import backdrop from 'assets/images/backdrop.jpg';

export const style = {
	content: {
		backgroundImage: `url(${backdrop})`,
	},
};
