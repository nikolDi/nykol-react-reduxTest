import { Switch as RoutesSwitch } from './switch';
import { routes, __ROOT_ROUTE__ } from './tree';

export { RoutesSwitch, routes, __ROOT_ROUTE__ };
