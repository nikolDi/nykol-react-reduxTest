export { View as Switch } from './view';
