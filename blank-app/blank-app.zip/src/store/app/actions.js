// import { createAction } from '../utils';

export const OActionTypes = {
	prefix: '@app',
};
